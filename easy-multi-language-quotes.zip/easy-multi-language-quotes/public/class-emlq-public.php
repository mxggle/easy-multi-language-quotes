<?php

class EMLQ_Public {

	private $plugin_name;
	private $version;
	private $option_name = 'emlq_settings';

	public function __construct( $plugin_name, $version ) {
		$this->plugin_name = $plugin_name;
		$this->version     = $version;
	}

	public function enqueue_styles() {
		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/emlq-public.css', array(), $this->version, 'all' );
	}

	public function render_shortcode( $atts ) {
		$options = get_option( $this->option_name );
		$all_quotes = get_option( 'emlq_all_quotes' );

		if ( empty( $all_quotes ) || ! is_array( $all_quotes ) ) {
			return '';
		}

		$frequency = isset( $options['frequency'] ) ? $options['frequency'] : 'always';
		$selected_quote = $this->get_quote_based_on_frequency( $all_quotes, $frequency );

		if ( ! $selected_quote ) {
			return '';
		}

		return $this->generate_html( $selected_quote );
	}

	private function get_quote_based_on_frequency( $quotes, $frequency ) {
		if ( 'always' === $frequency ) {
			return $quotes[ array_rand( $quotes ) ];
		}

		$transient_name = 'emlq_current_quote';
		$cached_quote = get_transient( $transient_name );

		if ( false !== $cached_quote ) {
			return $cached_quote;
		}

		$new_quote = $quotes[ array_rand( $quotes ) ];
		$expiration = ( 'hourly' === $frequency ) ? HOUR_IN_SECONDS : DAY_IN_SECONDS;

		set_transient( $transient_name, $new_quote, $expiration );

		return $new_quote;
	}

	private function generate_html( $quote ) {
		// Prepare data safely
		$zh = isset( $quote['quote']['zh'] ) ? $quote['quote']['zh'] : '';
		$en = isset( $quote['quote']['en'] ) ? $quote['quote']['en'] : '';
		$ja = isset( $quote['quote']['ja'] ) ? $quote['quote']['ja'] : '';
		$author = isset( $quote['author'] ) ? $quote['author'] : '';

		ob_start();
		?>
		<div class="easy-quotes-container">
			<div class="easy-quotes-quote">
				<?php if ( $zh ) : ?>
					<div class="emlq-text emlq-zh"><?php echo esc_html( $zh ); ?></div>
				<?php endif; ?>
				
				<?php if ( $en ) : ?>
					<div class="emlq-text emlq-en"><?php echo esc_html( $en ); ?></div>
				<?php endif; ?>

				<?php if ( $ja ) : ?>
					<div class="emlq-text emlq-ja"><?php echo esc_html( $ja ); ?></div>
				<?php endif; ?>

				<?php if ( $author ) : ?>
					<div class="emlq-author">- <?php echo esc_html( $author ); ?></div>
				<?php endif; ?>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}
}
